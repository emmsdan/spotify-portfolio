import React from "react";

export const AudioContext = React.createContext({})