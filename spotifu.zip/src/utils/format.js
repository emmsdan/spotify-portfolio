export const combineClasses = (...arg) => {
    return arg.join(' ')
}